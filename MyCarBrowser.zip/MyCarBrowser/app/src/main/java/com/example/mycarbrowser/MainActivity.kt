package com.example.mycarbrowser

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import java.net.URLEncoder

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var addressBar: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
        }

        addressBar = EditText(this).apply {
            hint = "اكتب موقعاً أو كلمة بحث"
            singleLine = true
            imeOptions = EditorInfo.IME_ACTION_GO
        }

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
        }

        val topBar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
            addView(addressBar, LinearLayout.LayoutParams(0, 52, 1f))
            addView(Button(this@MainActivity).apply {
                text = "اذهب"
                setOnClickListener { openAddress() }
            })
        }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(Button(this@MainActivity).apply {
                text = "رجوع"
                setOnClickListener { if (webView.canGoBack()) webView.goBack() }
            }, LinearLayout.LayoutParams(0, 48, 1f))
            addView(Button(this@MainActivity).apply {
                text = "تحديث"
                setOnClickListener { webView.reload() }
            }, LinearLayout.LayoutParams(0, 48, 1f))
            addView(Button(this@MainActivity).apply {
                text = "للأمام"
                setOnClickListener { if (webView.canGoForward()) webView.goForward() }
            }, LinearLayout.LayoutParams(0, 48, 1f))
        }

        addressBar.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                openAddress()
                true
            } else false
        }

        root.addView(topBar)
        root.addView(controls)
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        webView.loadUrl("https://www.google.com")
    }

    private fun openAddress() {
        val input = addressBar.text.toString().trim()
        if (input.isEmpty()) {
            Toast.makeText(this, "اكتب موقعاً أو كلمة بحث", Toast.LENGTH_SHORT).show()
            return
        }

        val target = if (input.contains(" ") || !input.contains(".")) {
            "https://www.google.com/search?q=" + URLEncoder.encode(input, "UTF-8")
        } else {
            val normalized = if (input.startsWith("http://") || input.startsWith("https://")) {
                input
            } else {
                "https://$input"
            }
            normalized
        }
        webView.loadUrl(target)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
