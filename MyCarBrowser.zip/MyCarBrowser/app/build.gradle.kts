plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.mycarbrowser"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.mycarbrowser"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
